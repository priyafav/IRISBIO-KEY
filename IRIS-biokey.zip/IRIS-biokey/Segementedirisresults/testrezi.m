im=imread('1-segmented1.bmp');
im2=imresize(im,[64,64]);
imwrite(im2, [num2str(1) '-cons1.bmp']);