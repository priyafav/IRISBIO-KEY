
load('cd_rca_curve2.mat');
tt=size(cd_rca,2);
kt=size(cd_rca,1);
cds=[];
cds=100*cd_rca(:,1:tt);
for i=1:100
    for j=1:100
        res_cds(i,j)=1-norm(cds(i,:)-cds(j,:))/(norm(cds(i,:))+norm(cds(j,:)));
    end
 end


result_cds=[];
for j=1:100
    for i=1:tt
        result_cds(j,i)=test_pointssss(test_pointssss(round(abs(cds(j,i))),10),15);
    end
end
% 
% result_cds11=[];
% for j=1:100
%     for i=1:tt
%         result_cds11{j,i}=dec2bin(round(test_pointssss(round(abs(cds(j,i))),5)),8);
%     end
% end
for i=1:100
    for j=1:100
        distcds(i,j)=1-norm(result_cds(i,:)-result_cds(j,:))/(norm(result_cds(i,:))+norm(result_cds(j,:)));
    end
 end

resl=[];
g=1;
d2=result_cds;
for f=1:5:100
 k=1;
 diste1=[];
for i=f:f+4
    for j=f:f+4
      diste1{k}=find(d2(i,:)==d2(j,:));
      k=k+1;
    end
end
s=zeros(25,tt);
for i=1:25
      for j=1:size(diste1{i},2)
          for k=1:tt
            if(diste1{i}(j)==k)  
               s(i,k)=k;
            end
          end
      end
end
res=[];
for i=1:tt
    res(i)=all((s(:,i)));
end

resl{g}=find(res==1);
g=g+1;
end
s1=[];
for i=1:20
      for j=1:size(resl{1,i},2)
          for k=1:tt
            if(resl{1,i}(j)==k)  
               s1(i,k)=k;
            end
          end
      end
end
rest=[];
for i=1:tt
    rest(i)=(length(find((s1(:,i))==i))>=10);
end
key=[];
key=find(rest);
cd3=[];

cd4=round(result_cds(:,key));
for i=1:100
    for j=1:100
        result_db2(i,j)=sum(cd4(i,:)==cd4(j,:))/size(cd4,2);
    end
end
