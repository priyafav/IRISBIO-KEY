function feature=spld1(img)   
% Radius and Neighborhood
    R=1;
    P=8;
    feature=[];
    % LBP needed a mapping function
    mapping=getmapping(P,'u2');

    [Out edge] = kirschEdge(img);
     
     
     LBP_H1 = spl(edge(:,:,1), mapping,'hist');
     LBP_H2 = spl(edge(:,:,2), mapping,'hist');
     LBP_H3 = spl(edge(:,:,3), mapping,'hist');
     LBP_H4 = spl(edge(:,:,4), mapping,'hist');
     LBP_H5 = spl(edge(:,:,5), mapping,'hist');
     LBP_H6 = spl(edge(:,:,6), mapping,'hist');
     
     LBP_H = [LBP_H1 LBP_H2 LBP_H3 LBP_H4 LBP_H5 LBP_H6];
     
     feature = [feature;LBP_H];

end