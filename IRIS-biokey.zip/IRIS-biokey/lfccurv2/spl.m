function [result,res3]=spl(res,mapping,mode)
res=res(:,:,1);
p=double(res);
[m,n]=size(res);
histo=zeros(1,256);
for i=1:m-2
    for j=1:n-2
        b(1)=p(i+1,j+1)>=p(i+1,j); b(2)=p(i+1,j)>=p(i+2,j);
        b(3)=p(i+2,j)>=p(i+2,j+1); b(4)=p(i+2,j+1)>=p(i+2,j+2);
        b(5)=p(i+2,j+2)>=p(i+1,j+2); b(6)=p(i+1,j+2)>=p(i,j+2);
        b(7)=p(i,j+2)>=p(i,j+1); b(8)=p(i,j+1)>=p(i,j);
        spl(i,j)=0;
        for ii=1:8
            spl(i,j)=spl(i,j)+b(ii)*2^(8-ii);
        end
    end
end
%histo=imhist(uint8(spl));
result=spl;
res3=spl;
%Apply mapping if it is defined
if isstruct(mapping)
    bins = mapping.num;
    for i = 1:size(result,1)
        for j = 1:size(result,2)
            result(i,j) = mapping.table(result(i,j)+1);
        end
    end
end

Pattern = hist(result(:),0:(bins-1));
Pattern = Pattern/sum(Pattern);

% if (strcmp(mode,'h') || strcmp(mode,'hist') || strcmp(mode,'nh'))
%     % Return with LBP histogram if mode equals 'hist'.
%     Pattern=hist(result(:),0:(bins-1));
%     if (strcmp(mode,'nh'))
%         Pattern=Pattern/sum(Pattern);
%     end
% end

if (strcmp(mode,'h') || strcmp(mode,'hist') || strcmp(mode,'nh'))
    % Return with LBP histogram if mode equals 'hist'.
    result=hist(result(:),0:(bins-1));
    if (strcmp(mode,'nh'))
        result=result/sum(result);
    end
else
    %Otherwise return a matrix of unsigned integers
    if ((bins-1)<=intmax('uint8'))
        result=uint8(result);
    elseif ((bins-1)<=intmax('uint16'))
        result=uint16(result);
    else
        result=uint32(result);
    end
end
%result
end