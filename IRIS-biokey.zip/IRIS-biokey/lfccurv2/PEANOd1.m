function feature=PEANOd1(img)   
% Radius and Neighborhood
    R=1;
    P=8;
    feature=[];
    % LBP needed a mapping function
    mapping=getmapping(P,'u2');

    [Out edge] = kirschEdge(img);
     
     
     LBP_H1 = PEANO(edge(:,:,1), mapping,'hist');
     LBP_H2 = PEANO(edge(:,:,2), mapping,'hist');
     LBP_H3 = PEANO(edge(:,:,3), mapping,'hist');
     LBP_H4 = PEANO(edge(:,:,4), mapping,'hist');
     LBP_H5 = PEANO(edge(:,:,5), mapping,'hist');
     LBP_H6 = PEANO(edge(:,:,6), mapping,'hist');
     
     LBP_H = [LBP_H1 LBP_H2 LBP_H3 LBP_H4 LBP_H5 LBP_H6];
     
     feature = [feature;LBP_H];

end