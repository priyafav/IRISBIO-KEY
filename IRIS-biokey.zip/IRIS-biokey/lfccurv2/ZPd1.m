function feature=ZPd1(img)   
% Radius and Neighborhood
    R=1;
    P=8;
    feature=[];
    % LBP needed a mapping function
    mapping=getmapping(P,'u2');

    [Out edge] = kirschEdge(img);
     
     
     LBP_H1 = ZP1(edge(:,:,1), mapping,'hist');
     LBP_H2 = ZP1(edge(:,:,2), mapping,'hist');
     LBP_H3 = ZP1(edge(:,:,3), mapping,'hist');
     LBP_H4 = ZP1(edge(:,:,4), mapping,'hist');
     LBP_H5 = ZP1(edge(:,:,5), mapping,'hist');
     LBP_H6 = ZP1(edge(:,:,6), mapping,'hist');
     
     LBP_H = [LBP_H1 LBP_H2 LBP_H3 LBP_H4 LBP_H5 LBP_H6];
     
     feature = [feature;LBP_H];

end