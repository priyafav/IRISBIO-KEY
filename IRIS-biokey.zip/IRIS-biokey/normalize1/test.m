tic
for i=1:100
    d = load([num2str(i) '-circle' '.mat']);
    im=(imread([num2str(i) '-enhance' '.bmp']));
    global DIAGPATH             % Global variable that is needed in the following
    DIAGPATH = '.';

    [im_normalized, ~] = normaliseiris(double(im), d.center(1), d.center(2), d.radius, ...
		d.center_p(1), d.center_p(2), d.radius_p, 'output_image', 64, 512);
    im_en=adapthisteq(enhance_image(im_normalized,300,7));
    imwrite(im_en, [num2str(i) , '-normalized.bmp']);
%     imshow(im_normalized);
   seg = tile(im_en,4,2,0);
%     for i=1:2
%         for j=1:4
%             figure;
%            imshow(seg{i,j});
%         end
%         %
%     end
    seg1=[seg{1,3};seg{2,3}];
  imwrite(seg1, [num2str(i) , '-segmented1.bmp']);
end
toc;