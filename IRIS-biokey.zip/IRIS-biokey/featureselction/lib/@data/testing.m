
function [dat] =  testing(algo,dat)
  %% return this, because this is data
  dat=algo; 
  
  